<html>
    <head>
        <title>Registration form</title>
    </head>
    <body>
        <form action="task1_file.php" method="post">
            <span>Enter your First name:</span>
            <input type="text" name="fname"><br><br>
            <span>Enter your Second name:</span>
            <input type="text" name="sname"><br><br>
            <span>DOB</span>
            <input type="date" name="dob"><br><br>
            <span>mobile no.</span>
            <input type="number" name="m_no"><br><br>
            <span>Email ID:</span>
            <input type="email" name="email"><br><br>
            <span>Age:</span>
            <input type="number" name="age"><br><br>
            <span>Gender:</span>
            <input type="radio" name="gender" value="female">Female
            <input type="radio" name="gender" value="male">Male <br><br>
            <span>City/village</span>
            <input type="text" name="city"><br><br>
            <span>District</span>
            <input type="text" name="district"><br><br>
            <span>Occupation</span>
            <input type="text" name="Occupation"><br><br>
            <input type="checkbox" name="write">
            <span>Your all information is write</span><br><br>
            <button name="submit">Submit</button>
        </form>
    </body>
</html>